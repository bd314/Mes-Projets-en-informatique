<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>MTFO Dashboard</title>

<meta name="Publisher"              content="Enzo">
<meta name="Copyright"              content="Copyright © 2013 MTFO">
<meta name="Distribution"           content="Global">
<meta name="Rating"                 content="General">
<meta name="Robots"                 content="index, follow">
<meta name="Revisit-After"          content="10 days">
<meta name="distribution"           content="global" />
<meta name="msvalidate.01"          content="A3E292C2CE4A748F58FF7AB41ECF4BDE" />
<meta http-equiv="Content-Type"     content="text/html; charset=ISO-8859-1" />
<meta charset="UTF-8">
<meta http-equiv="Content-Language" content="fr">
<meta name="Title" lang="fr"        content="MTFO">
<meta name="Identifier-url"         content="http://www.mtfo.fr">
<meta name="Description" lang="fr"  content="MTFO.fr est un network vous proposant de multiples sections tels que Minecraft (la principalité et la base du site), la musique, etc .">
<meta name="Abstract"               content="MTFO.fr est un network vous proposant de multiples sections tels que Minecraft (la principalité et la base du site), la musique, etc .">
<meta name="keywords" lang="fr"     content="mtfo, MTFO, Mtfo, enzo, enzomerand, enzo7337, minecraft, Minecraft, music, musique, launcher, launchers, heberg, cloud, hebergement">
<meta name="Category"               content="Jeux vidéos et autres">
<meta name="Author" lang="fr"       content="Enzo">
<meta name="Reply-to"               content="enzo7337@gmail.com; charset=UTF-8" />
<meta content="True" name="HandheldFriendly" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<link rel="apple-touch-icon"        href="http://minecraft.net/apple-touch-icon.png">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

		<!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!-- Le styles -->
        <link href="../assets/css/mtfo.css" rel="stylesheet">
		<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/css/jigowatt.css" rel="stylesheet">
        <link href="../assets/css/kd-button.css" rel="stylesheet">
		<link rel="shortcut icon" href="../assets/img/favicon.ico">
	</head>

<body style="background-image: url(http://ni-cloud.fr/images/bg.png)">

<!-- Navigation Bar
================================================== -->
        <div id="header" style="margin-top: 23px;">
            <div class="header_wrapper">
                <a href="" class="main_logo"><img src="assets/img/logo.png" width="291" height="70"></a>
                <div class="support">
                    <div>
                        		<a class="disconnect" href="login.php" title="Votre dashboard MTFO"><img src="assets/img/glyphicons_203_lock.png" style="width: 9px;margin-top: -3px;margin-right: 2px;"> Connexion</a>
		                    </div>
                </div>
                        <div class="menu">
                            <div class="full" style="position: relative;">
                                <ul class="main" id="menuDropper"> 
                                    <li><a href="index.php">                                Home       </a></li>
                                    <li><a href="minecraft.php">                            Minecraft  </a></li>
                                    <li><a href="http://heberg.mtfo.fr">                    Cloud      </a></li>
                                    <li><a href="music.php">                                Musique    </a></li>
                                    <li><a href="boutique.php">                             Boutique   </a></li>
                                    <li><a target="blank" href="http://portfolio.mtfo.fr">  Portfolio  </a></li>
                                    <li><a href="info.php">                                 À propos   </a></li>
                                </ul>
                            </div>
                        </div>
            </div>
        </div>

<!-- Main content
================================================== -->
		<div class="container" >
			<div class="row">

				<div class="span12">
 Vous devez être connecté pour faire une demande partenariat.