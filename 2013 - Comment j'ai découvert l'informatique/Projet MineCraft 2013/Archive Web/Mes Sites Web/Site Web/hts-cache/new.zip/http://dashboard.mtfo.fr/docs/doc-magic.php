<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>MTFO Dashboard</title>

<meta name="Publisher"              content="Enzo">
<meta name="Copyright"              content="Copyright © 2013 MTFO">
<meta name="Distribution"           content="Global">
<meta name="Rating"                 content="General">
<meta name="Robots"                 content="index, follow">
<meta name="Revisit-After"          content="10 days">
<meta name="distribution"           content="global" />
<meta name="msvalidate.01"          content="A3E292C2CE4A748F58FF7AB41ECF4BDE" />
<meta http-equiv="Content-Type"     content="text/html; charset=ISO-8859-1" />
<meta charset="UTF-8">
<meta http-equiv="Content-Language" content="fr">
<meta name="Title" lang="fr"        content="MTFO">
<meta name="Identifier-url"         content="http://www.mtfo.fr">
<meta name="Description" lang="fr"  content="MTFO.fr est un network vous proposant de multiples sections tels que Minecraft (la principalité et la base du site), la musique, etc .">
<meta name="Abstract"               content="MTFO.fr est un network vous proposant de multiples sections tels que Minecraft (la principalité et la base du site), la musique, etc .">
<meta name="keywords" lang="fr"     content="mtfo, MTFO, Mtfo, enzo, enzomerand, enzo7337, minecraft, Minecraft, music, musique, launcher, launchers, heberg, cloud, hebergement">
<meta name="Category"               content="Jeux vidéos et autres">
<meta name="Author" lang="fr"       content="Enzo">
<meta name="Reply-to"               content="enzo7337@gmail.com; charset=UTF-8" />
<meta content="True" name="HandheldFriendly" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<link rel="apple-touch-icon"        href="http://minecraft.net/apple-touch-icon.png">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

		<!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!-- Le styles -->
        <link href="../assets/css/mtfo.css" rel="stylesheet">
		<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/css/jigowatt.css" rel="stylesheet">
        <link href="../assets/css/kd-button.css" rel="stylesheet">
		<link rel="shortcut icon" href="../assets/img/favicon.ico">
	</head>

<body style="background-image: url(http://ni-cloud.fr/images/bg.png)">

<!-- Navigation Bar
================================================== -->
        <div id="header" style="margin-top: 23px;">
            <div class="header_wrapper">
                <a href="" class="main_logo"><img src="../assets/img/logo.png" width="291" height="70"></a>
                <div class="support">
                    <div>
                        		<a class="disconnect" href="../login.php" title="Votre dashboard MTFO"><img src="../assets/img/glyphicons_203_lock.png" style="width: 9px;margin-top: -3px;margin-right: 2px;"> Connexion</a>
		                    </div>
                </div>
                        <div class="menu">
                            <div class="full" style="position: relative;">
                                <ul class="main" id="menuDropper"> 
                                    <li><a href="../index.php">                                Home       </a></li>
                                    <li><a href="../minecraft.php">                            Minecraft  </a></li>
                                    <li><a href="http://heberg.mtfo.fr">                       Cloud      </a></li>
                                    <li><a href="../music.php">                                Musique    </a></li>
                                    <li><a href="../boutique.php">                             Boutique   </a></li>
                                    <li><a target="blank" href="http://portfolio.mtfo.fr">     Portfolio  </a></li>
                                    <li><a href="../info.php">                                 À propos   </a></li>
                                </ul>
                            </div>
                        </div>
            </div>
        </div>

<!-- Main content
================================================== -->
		<div class="container" >
			<div class="row">

				<div class="span12">

<h1>Informations</h1>
	<h4>Vous êtes sur une page d'information, vous pouvez nous contactez par cette page</h4>
    <p>Sur cette page, votre IP est enregistrée !</p>
    <a href="../info.php" class="btn btn-info">Support</a> <a class="btn disabled">Documentation launchers</a> <a class="btn" href="#ml" role="button" data-toggle="modal">Mentions légales</a> <a class="btn btn-inverse" href="../partners">Partenaires</a>
        <br />
		<br />
        <br />

<center>

<div class="pager">
  <ul>
    <li>
      <a style="text-decoration: none;" href="doc-mtfo.php">MTFO</a> 
    </li>
    <li>
      <a href="doc-nodus.php" style="text-decoration: none;">NODUS</a> 
    </li>
    <li class="disabled">
      <a style="text-decoration: none;">WEEPCRAFT</a> 
    </li>
    <li>
      <a href="doc-magic.php" style="text-decoration: none;">MAGIC LAUNCHER</a> 
    </li>
  </ul>
</div>
<br>

<div class="page-content">


<!-- 960 Container -->
<div class="container">

<img src="http://minecraft.fr/wp-content/uploads/2012/01/magiclauncher_logo.png">
	<!-- Texts -->
	<div class="two-thirds column">
		<h3 style="margin: -10px 0 15px 0;">Description du launcher</h3>
		<p>Voici le launcher Nodus, un launcher qui propose des cheats ! Version <b>1.5.2</b></p>
		<dl>
    <dt><i>Les fonctions</i> :</dt>
<dd>selectable minecraft.jar</dd>
<dd>selectable environment</dd>
<dd>automatic version detection</dd>
<dd>configurable window size, also maximized</dd>
<dd>selectable minecraft folder</dd>
<dd>selectable java executable</dd>
<dd>java memory limit</dd>
<dd>java custom parameters</dd>
<dd>show error log</dd>
<dd>multiple user profiles</dd>
<dd>remember password</dd>
<dd>configuration profiles</dd>
<br>
<dt>Images :</dt>
<dd>
<br>
<img src="http://i.imgur.com/SZvAfni.png">
<br>
<img src="http://i.imgur.com/GXu27xa.png">
<br>
<img src="http://i.imgur.com/81kV4wR.png">
<br>
<img src="http://i.imgur.com/WSY0ZDk.png">
</dd>

    <br>
  </dl>
	</div>
</div>

<br />
</div>
</center>

<!-- Footer
================================================== -->

	</div> <!-- /.span9 -->
	</div> <!-- /.row -->   

<div id="ml" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Mentions légales et informations</h3>
  </div>
  <div class="modal-body">
    <h3>A propos</h3>
    <p>MTFO.fr ou clinet.mtfo.fr vous propose du contenu principalement sur Minecraft, mais ausi d'autres sections, hébergement, musique et graphisme. Vous pouvez téléchargez en toute sécurité les launchers ou fichiers, car notre deuxième principalité est la sécurité. Un service de contact sera toujours disponible avec cette email : enzo7337@gmail.com</p>
    <h3>Politique de confidentialité</h3>
    <p>Votre mot de passe est strictement personnel, il vous appartient de le conserver secret. Une utilisation frauduleuse d'un compte ne saurait nous tenir pour responsable, à moins que l'origine du problème nous soit directement et uniquement imputable.

Toutes les informations de votre profil ne sont pas publiques. Votre adresse de messagerie ne sera pas visible par les autres utilisateurs et aucune des informations fournies ne seront vendues ou cédées à un tiers : elles sont exclusivement destinées au site MTFO.fr.

En application de la loi française n°78-17 du 6 janvier 1978 relative à l'informatique, aux fichiers et aux libertés, vous disposez des droits d'accès, d'opposition et de rectification des données vous concernant. Vous pouvez exercer à tout moment ce droit en allant dans l'interface de gestion de votre compte.

En revanche, votre IP est enregistré, seulement sur les pages contenant un formulaire, pour lutter contre le spam, et pour garder de la sécurité. Après analyse du formulaire, soit votre IP est détruite de nos registres si aucun spam ou autre n'est détécté, soit elle est banni et dévoilé à la police si il y a eu toutes tentative de spam ou autres (insultes, etc...). Vous pourrez accédez au logs/connexion à votre compte via le panel, dans vos options. Nous iront voir qu'en cas de problème.
Les bases de données sont protégées par les dispositions de la loi du 1er juillet 1998 transposant la directive 96/9 du 11 mars 1996 relative à la protection juridique des bases de données.</p>
   
   <h3>Politique générale</h3>
    <p>Toute utilisation des Forums et/ou des services proposés non conforme aux conditions d'utilisation peut entrainer une suspension temporaire ou la suppression définitive de votre compte et de ses données relatives, sans préavis ni indemnités. En cas de litige entre plusieurs utilisateurs ou plaintes justifiées d'autres utilisateurs, nous pouvons également prendre ces mesures.
Lorsque nous procédons à ces solutions extrêmes, un modérateur ou administrateur vous contactera sur l'adresse de messagerie de votre profil afin d'expliquer la ou les raisons.</p>
 
 <h3>Edition du site</h3>
 <p>
MTFO - Launchers Minecraft<br>
Web : www.mtfo.fr<br>
Contact : enzo7337@gmail.com<br>
<br>
Enzo Merand<br>
Développeur - Responsable de projet<br>
<br>
CMS du site<br>
Bootstrap<br>
http://twitter.github.io/bootstrap/<br>
<br>
Propulsion du site (PHP)<br>
Jigowatt<br>
PHP Login & User Management<br>
<br>
Hébergement des données<br>
OVH<br>
2, rue Kellermann<br>
59100 Roubaix<br>
France<br>
Web : www.ovh.com</p>

<h3>Mails</h3>
<p>Nos emails ne sont pas envoyé n'importe comment. Nous vérifions tout le temps qu'il n'y ai pas de failles/problèmes dans le mail. Nous vérifions l'identité de l'utilisateur avant d'envoyer un mail. Pour les personnes faisant parties (inscrites) du dashboard MTFO, les emails contenant des informations personnelles (exclu le mot de passe et l'email de l'utilisateur) sont envoyés 3 fois maximum par mois, sous demande de l'utlisateur. Nous vous demanderont <b>jamais</b> votre mot de passe par mail. Aussi, pour des failles quelque peu connues, votre login (email ou pseudo) ne sera jamais envoyé avec votre mot de passe (lien de réinitialisation). Nous vous enverrons jamais un mail contenant votre mot de passe, seul un lien pour le retrouver peut vous être envoyé.</p>

<h3>Propriété intellectuelle</h3>
<p>Tous les logiciels, présentations d'information, jeux, dénominations, noms commerciaux, textes, commentaires, images, illustrations, marques de produits ou de services, inventions, et de manière générale, toute création de quelque nature qu'elle soit, qui sont accessibles à l'aide du site mtfo.fr, demeurent la propriété exclusive de leurs titulaires respectifs.
La constitution et la télétransmission de données, d'informations, de logiciels, de jeux s'effectuent sous le contrôle et la responsabilité de l'utilisateur.
L'Utilisateur est autorisé à utiliser l'ensemble des programmes, jeux, services, fonctionnalités, mis à sa disposition au sein du service en ligne mtfo.fr, dans le respect des droits de propriété intellectuelle de MTFO, des fournisseurs de programmes, des éditeurs de jeux ou de tout autre ayant droit, étant entendu que seule est autorisée l'utilisation pour un usage privé.
En particulier l'utilisateur fait son affaire personnelle de posséder les droits d'utilisation des jeux qu'il utilise et ne pourra engager la responsabilité de MTFO. à quelque titre que ce soit si lui même ou des utilisateurs du serveur auquel il aura donné accès ne possédaient pas les droits requis pour y avoir accès. 
</p>

<h3>Copyrights</h3>
<p>
<img border="0" alt="Copyrighted.com Registered &amp; Protected 
KKD9-RZJQ-U85P-V5VU" title="Copyrighted.com Registered &amp; Protected 
KKD9-RZJQ-U85P-V5VU" width="150" height="40" src="http://static.copyrighted.com/images/seal.gif"><br>
MTFO.fr est déclaré sous le numero KKD9-RZJQ-U85P-V5VU du site <a href="http://www.copyrighted.com/">http://www.copyrighted.com</a>.<br> Fingerprint : 0fe49ffdfc3e0255d25f2ef49b5f3bcd24dc0100b30ad00da448a909b8d83418<br>
Certaines images appartiennent aux sociétés suivantes : Mojang AB(<a href="http://mojang.com">http://mojang.com</a>), Glyphicons(<a href="http://glyphicons.com/">http://glyphicons.com/</a>).
</p>
 </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">J'ai pris connaissance des conditions</button>
  </div>
</div>

</div> <!-- /.container -->

	<!-- Le javascript -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script src="assets/js/bootstrap-transition.js"></script>
	<script src="assets/js/bootstrap-collapse.js"></script>
	<script src="assets/js/bootstrap-modal.js"></script>
	<script src="assets/js/bootstrap-dropdown.js"></script>
	<script src="assets/js/bootstrap-button.js"></script>
	<script src="assets/js/bootstrap-tab.js"></script>
	<script src="assets/js/bootstrap-alert.js"></script>
	<script src="assets/js/bootstrap-tooltip.js"></script>
	<script src="assets/js/jquery.ba-hashchange.min.js"></script>
	<script src="assets/js/jquery.validate.min.js"></script>
	<script src="assets/js/jquery.placeholder.min.js"></script>
	<script src="assets/js/jquery.jigowatt.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.4/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/jquery.jigowatt.js"></script><!-- AJAX Form Submit -->

  </body>
 
	<footer>
		<hr>
		<center style="margin-bottom: -25px;">
	        <span class="copyright">Copyright © 2013 - MTFO Version 4.1.4 - Tous droits réservés. <a style="color: rgb(15, 134, 180);" href="#ml" role="button" data-toggle="modal">Mentions légales</a></span>
        </center>
	<br />
	<br />
<center><script type="text/javascript"><!--
google_ad_client = "ca-pub-4102336494627461";
/* PUB-FOOTER */
google_ad_slot = "5066835698";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<br>
<div style="color:#000"><a href="partners.php" style="color:#000">Partenaires</a> | <a href="info.php" style="color:#000">Contact</a> | <a href="info.php" style="color:#000">Suggestion</a> | <a href="" style="color: #8D0000;">Recrutement</a></div>
<br>
</center>
	</footer>
</html>
