<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>MTFO Dashboard</title>

<meta name="Publisher"              content="Enzo">
<meta name="Copyright"              content="Copyright © 2013 MTFO">
<meta name="Distribution"           content="Global">
<meta name="Rating"                 content="General">
<meta name="Robots"                 content="index, follow">
<meta name="Revisit-After"          content="10 days">
<meta name="distribution"           content="global" />
<meta name="msvalidate.01"          content="A3E292C2CE4A748F58FF7AB41ECF4BDE" />
<meta http-equiv="Content-Type"     content="text/html; charset=ISO-8859-1" />
<meta charset="UTF-8">
<meta http-equiv="Content-Language" content="fr">
<meta name="Title" lang="fr"        content="MTFO">
<meta name="Identifier-url"         content="http://www.mtfo.fr">
<meta name="Description" lang="fr"  content="MTFO.fr est un network vous proposant de multiples sections tels que Minecraft (la principalité et la base du site), la musique, etc .">
<meta name="Abstract"               content="MTFO.fr est un network vous proposant de multiples sections tels que Minecraft (la principalité et la base du site), la musique, etc .">
<meta name="keywords" lang="fr"     content="mtfo, MTFO, Mtfo, enzo, enzomerand, enzo7337, minecraft, Minecraft, music, musique, launcher, launchers, heberg, cloud, hebergement">
<meta name="Category"               content="Jeux vidéos et autres">
<meta name="Author" lang="fr"       content="Enzo">
<meta name="Reply-to"               content="enzo7337@gmail.com; charset=UTF-8" />
<meta content="True" name="HandheldFriendly" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<link rel="apple-touch-icon"        href="http://minecraft.net/apple-touch-icon.png">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

		<!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!-- Le styles -->
        <link href="../assets/css/mtfo.css" rel="stylesheet">
		<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/css/jigowatt.css" rel="stylesheet">
        <link href="../assets/css/kd-button.css" rel="stylesheet">
		<link rel="shortcut icon" href="../assets/img/favicon.ico">
	</head>

<body style="background-image: url(http://ni-cloud.fr/images/bg.png)">

<!-- Navigation Bar
================================================== -->
        <div id="header" style="margin-top: 23px;">
            <div class="header_wrapper">
                <a href="?PHPSESSID=188jjms9ha69dutqd6goli5jt0" class="main_logo"><img src="assets/img/logo.png" width="291" height="70"></a>
                <div class="support">
                    <div>
                        		<a class="disconnect" href="login.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0" title="Votre dashboard MTFO"><img src="assets/img/glyphicons_203_lock.png" style="width: 9px;margin-top: -3px;margin-right: 2px;"> Connexion</a>
		                    </div>
                </div>
                        <div class="menu">
                            <div class="full" style="position: relative;">
                                <ul class="main" id="menuDropper"> 
                                    <li><a href="index.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">                                Home       </a></li>
                                    <li><a href="minecraft.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">                            Minecraft  </a></li>
                                    <li><a href="http://heberg.mtfo.fr">                    Cloud      </a></li>
                                    <li><a href="music.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">                                Musique    </a></li>
                                    <li><a href="boutique.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">                             Boutique   </a></li>
                                    <li><a target="blank" href="http://portfolio.mtfo.fr">  Portfolio  </a></li>
                                    <li><a href="info.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">                                 À propos   </a></li>
                                </ul>
                            </div>
                        </div>
            </div>
        </div>

<!-- Main content
================================================== -->
		<div class="container" >
			<div class="row">

				<div class="span12">

<div class="hero-unit">
	<h1>Bienvenue sur le<br>Dashboard MTFO</h1>
	<h2>Découvrez dès maintenant ce que c'est !</h2>
    <p>

        <a href="http://client.mtfo.fr/sign_up.php" target="_TOP" class="btn btn-large btn-primary">S'inscrire &raquo;</a>
        <a href="#info" role="button" data-toggle="modal" class="btn btn-large" style="width: 180px;">Qu'est ce que c'est ?</a>
	</p>
	<p class="info-links">
		<a href="docs/doc-mtfo.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0" target="_blank">Documentation</a>
		<a href="info.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0" target="_blank">Support</a>
	</p>
</div>

<hr>

<div class="features">
	<div class="row">
		<h1>De multiples fonctionnalités, MTFO est un grand réseau !</h1>
		<p class="intro">Découvrez nos fonctionnalités proposé ci-dessous</p>
		<div class="span6">
			<h2>Minecraft<small> Notre principalité</small></h2>
			<p>Cette catégorie que nous vous proposons, c'est la base de notre société ! Maintenant nous l'avons développé dans d'autres catégories, tel que la Musique ! Nous vous proposons pour cette catégorie de multiples launchers.<br><a href="#minecraft" role="button" data-toggle="modal">En savoir plus →</a></p>
		</div>

		<div class="span6">
			<h2>Musique<small> Un divertissement</small></h2>
			<p>Nous l'avons créé, développé et finie très recemment ! Vous pouvez y accéder par <a href="http://music.mtfo.fr">là</a> ou par <a href="http://www.music.mtfo.fr">içi</a> ! Nous proposons une musique par semaine, la musique du mois, vous pouvez aussi proposer vos musiques !<br><a href="#music" role="button" data-toggle="modal">En savoir plus →</a></p>
		</div>
	</div>

	<div class="row">
		<div class="span6">
			<h2>Hébergement<small> Une proposition</small></h2>
			<p>C'est une toute petite plateforme d'hébergement, sans aucune publicité, avec 1Go de stockage pour vous ! <a href="http://heberg.mtfo.fr">Acceder au site</a><br><a href="#heberg" role="button" data-toggle="modal">En savoir plus →</a></p>
		</div>

		<div class="span6">
			<h2>Boutique<small> Vos produit</small></h2>
			<p>Cette catégorie vous permet de vendre des produits. Mais elle vous permet de vendre que des produits téléchargables !<br><a href="#graph" role="button" data-toggle="modal">En savoir plus →</a></p>
		</div>
	</div>
</div>

<!-- Fenêtres modales -->
<div id="heberg" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Hébergement</h3>
  </div>
  <div class="modal-body">
    <h3>Infos</h3>
    <p>Cette plateforme d'hébergement vous offres 1Go gratuit, pour mettre en ligne des fichiers de tout types. Aucune publicité. Ce n'est pas une grande plateforme d'hébergement, mais une aide simple.</p>
 </div>
  <div class="modal-footer">
    <a class="btn primary" href="http://heberg.mtfo.fr">Aller sur le site</a>
    <button class="btn" data-dismiss="modal" aria-hidden="true">Ok</button>
  </div>
</div>


<div id="music" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Musique</h3>
  </div>
  <div class="modal-body">
    <h3>Infos</h3>
    <p>Cette section musique vous propose la musique du mois et les musiques de la semaine. Mais ce n'est pas tout ! Il y a beaucoups d'autres fonctionnalités. Vous pouvez maintenant proposer votre musique pour la semaine ou du mois, acheter les musiques proposées (en développement), écouter notre radio ou les radios partenaires (en développement) et vous pouvez aussi les télécharger ! Pour voir notre sélections de musiques (toutes les musiques), elles sont sur notre network <a href="http://www.youtube.com/mtfomusique">YouTube MTFO Music</a>.</p>
 </div>
  <div class="modal-footer">
    <a class="btn primary" href="http://music.mtfo.fr">Aller sur le site</a>
    <button class="btn" data-dismiss="modal" aria-hidden="true">Ok</button>
  </div>
</div>


<div id="graph" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Boutique</h3>
  </div>
  <div class="modal-body">
    <h3>Infos</h3>
    <p> Içi, vous pouvez vendre vos produits, uniquement des produits téléchargables. Vous gagnez toutes l'argent, nous récuperons aucune parts de vos ventes. Mais vous pouvez aussi proposer du contenu gratuit !</p>
 </div>
  <div class="modal-footer">
    <a class="btn primary" href="http://dashboard.mtfo.fr/boutique.php">Aller sur le site</a>
    <button class="btn" data-dismiss="modal" aria-hidden="true">Ok</button>
  </div>
</div>


<div id="info" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Qu'est ce que c'est ?</h3>
  </div>
  <div class="modal-body">
    <h3>L'histoire de MTFO et ses ancêtres</h3>
    <p>CrackHackDownload, c'était mon premier site web, qui permettait de cracker son iPod/iPhone/iPad. Il n'a pas durée longtemps, et s'est vite transformé en studio-gamer.com. Studio-Gamer proposait une ommunauté sur tous les jeux vidéos.<br>
<hr>
	Enfin est arrivé MTFO, depuis 1 an !
MTFO est devenue une petite société/organisation qui s'agrandie de jours en jours ! J'en ai créé un network (un réseau), qui s'est étendue dans la musique, l'hébergement, la publicité (MTFO Ads) et le graphisme. Sans oublié la catégorie principale : Minecraft. Minecraft était le début de MTFO ! Je proposait des launchers que j'avais codé moi-même. Et sa continue ! Mais avec une nouvelle interface, beaucoups plus de launchers et de fonctionnalités !
Pourquoi un espace membre en avant ? J'ai préférer mettre un espace membre en avant car je peux savoir qui suit le site. De plus cela fesait plus clean et puis je fais ce que je veux :) !
<hr>
<style>.ig-b- { display: inline-block; }
.ig-b- img { visibility: hidden; }
.ig-b-:hover { background-position: 0 -60px; } .ig-b-:active { background-position: 0 -120px; }
.ig-b-32 { width: 32px; height: 32px; background: url(//badges.instagram.com/static/images/ig-badge-sprite-32.png) no-repeat 0 0; }
@media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min--moz-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2 / 1), only screen and (min-device-pixel-ratio: 2), only screen and (min-resolution: 192dpi), only screen and (min-resolution: 2dppx) {
.ig-b-32 { background-image: url(//badges.instagram.com/static/images/ig-badge-sprite-32@2x.png); background-size: 60px 178px; } }</style>
<a href="http://instagram.com/enzo7337?ref=badge" class="ig-b- ig-b-32"><img src="//badges.instagram.com/static/images/ig-badge-32.png" alt="Instagram" /></a>
<iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2FHTMLCreators&amp;send=false&amp;layout=button_count&amp;width=88&amp;show_faces=false&amp;font=verdana&amp;colorscheme=light&amp;action=like&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:88px; height:21px;" allowTransparency="true"></iframe>
<iframe allowtransparency="true" frameborder="0" scrolling="no" src="https://platform.twitter.com/widgets/follow_button.1370380126.html#_=1370885471119&amp;dnt=true&amp;id=twitter-widget-1&amp;lang=en&amp;screen_name=enzo7337&amp;show_count=true&amp;show_screen_name=true&amp;size=m" class="twitter-follow-button twitter-follow-button" title="Twitter Follow Button" data-twttr-rendered="true" style="width: 227px; height: 20px;"></iframe>
<br>
</p>
 </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Ok</button>
  </div>
</div>

<div id="minecraft" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Minecraft</h3>
  </div>
  <div class="modal-body">
    <h3>Infos</h3>
    <p> C'est la première section à être créé ! Je vous propose ce service: je code des launchers Minecraft et Minecraft en lui même ! Si vous êtes pas doué en ce langage (Java), vous pouvez vous faire créer votre propre launcher, dont le prix de base est de 0,89 € ! (<a href="buycraft.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">En savoir plus içi</a>). Sinon, je propose des launchers gratuits, pour en avoir plusieurs, différents !<br>
</p>
 </div>
  <div class="modal-footer">
    <a class="btn" href="minecraft.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0">Aller sur le site</a>
    <button class="btn" data-dismiss="modal" aria-hidden="true">Ok</button>
  </div>
</div>

<!-- Footer
================================================== -->

	</div> <!-- /.span9 -->
	</div> <!-- /.row -->   

<div id="ml" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Mentions légales et informations</h3>
  </div>
  <div class="modal-body">
    <h3>A propos</h3>
    <p>MTFO.fr ou clinet.mtfo.fr vous propose du contenu principalement sur Minecraft, mais ausi d'autres sections, hébergement, musique et graphisme. Vous pouvez téléchargez en toute sécurité les launchers ou fichiers, car notre deuxième principalité est la sécurité. Un service de contact sera toujours disponible avec cette email : enzo7337@gmail.com</p>
    <h3>Politique de confidentialité</h3>
    <p>Votre mot de passe est strictement personnel, il vous appartient de le conserver secret. Une utilisation frauduleuse d'un compte ne saurait nous tenir pour responsable, à moins que l'origine du problème nous soit directement et uniquement imputable.

Toutes les informations de votre profil ne sont pas publiques. Votre adresse de messagerie ne sera pas visible par les autres utilisateurs et aucune des informations fournies ne seront vendues ou cédées à un tiers : elles sont exclusivement destinées au site MTFO.fr.

En application de la loi française n°78-17 du 6 janvier 1978 relative à l'informatique, aux fichiers et aux libertés, vous disposez des droits d'accès, d'opposition et de rectification des données vous concernant. Vous pouvez exercer à tout moment ce droit en allant dans l'interface de gestion de votre compte.

En revanche, votre IP est enregistré, seulement sur les pages contenant un formulaire, pour lutter contre le spam, et pour garder de la sécurité. Après analyse du formulaire, soit votre IP est détruite de nos registres si aucun spam ou autre n'est détécté, soit elle est banni et dévoilé à la police si il y a eu toutes tentative de spam ou autres (insultes, etc...). Vous pourrez accédez au logs/connexion à votre compte via le panel, dans vos options. Nous iront voir qu'en cas de problème.
Les bases de données sont protégées par les dispositions de la loi du 1er juillet 1998 transposant la directive 96/9 du 11 mars 1996 relative à la protection juridique des bases de données.</p>
   
   <h3>Politique générale</h3>
    <p>Toute utilisation des Forums et/ou des services proposés non conforme aux conditions d'utilisation peut entrainer une suspension temporaire ou la suppression définitive de votre compte et de ses données relatives, sans préavis ni indemnités. En cas de litige entre plusieurs utilisateurs ou plaintes justifiées d'autres utilisateurs, nous pouvons également prendre ces mesures.
Lorsque nous procédons à ces solutions extrêmes, un modérateur ou administrateur vous contactera sur l'adresse de messagerie de votre profil afin d'expliquer la ou les raisons.</p>
 
 <h3>Edition du site</h3>
 <p>
MTFO - Launchers Minecraft<br>
Web : www.mtfo.fr<br>
Contact : enzo7337@gmail.com<br>
<br>
Enzo Merand<br>
Développeur - Responsable de projet<br>
<br>
CMS du site<br>
Bootstrap<br>
http://twitter.github.io/bootstrap/<br>
<br>
Propulsion du site (PHP)<br>
Jigowatt<br>
PHP Login & User Management<br>
<br>
Hébergement des données<br>
OVH<br>
2, rue Kellermann<br>
59100 Roubaix<br>
France<br>
Web : www.ovh.com</p>

<h3>Mails</h3>
<p>Nos emails ne sont pas envoyé n'importe comment. Nous vérifions tout le temps qu'il n'y ai pas de failles/problèmes dans le mail. Nous vérifions l'identité de l'utilisateur avant d'envoyer un mail. Pour les personnes faisant parties (inscrites) du dashboard MTFO, les emails contenant des informations personnelles (exclu le mot de passe et l'email de l'utilisateur) sont envoyés 3 fois maximum par mois, sous demande de l'utlisateur. Nous vous demanderont <b>jamais</b> votre mot de passe par mail. Aussi, pour des failles quelque peu connues, votre login (email ou pseudo) ne sera jamais envoyé avec votre mot de passe (lien de réinitialisation). Nous vous enverrons jamais un mail contenant votre mot de passe, seul un lien pour le retrouver peut vous être envoyé.</p>

<h3>Propriété intellectuelle</h3>
<p>Tous les logiciels, présentations d'information, jeux, dénominations, noms commerciaux, textes, commentaires, images, illustrations, marques de produits ou de services, inventions, et de manière générale, toute création de quelque nature qu'elle soit, qui sont accessibles à l'aide du site mtfo.fr, demeurent la propriété exclusive de leurs titulaires respectifs.
La constitution et la télétransmission de données, d'informations, de logiciels, de jeux s'effectuent sous le contrôle et la responsabilité de l'utilisateur.
L'Utilisateur est autorisé à utiliser l'ensemble des programmes, jeux, services, fonctionnalités, mis à sa disposition au sein du service en ligne mtfo.fr, dans le respect des droits de propriété intellectuelle de MTFO, des fournisseurs de programmes, des éditeurs de jeux ou de tout autre ayant droit, étant entendu que seule est autorisée l'utilisation pour un usage privé.
En particulier l'utilisateur fait son affaire personnelle de posséder les droits d'utilisation des jeux qu'il utilise et ne pourra engager la responsabilité de MTFO. à quelque titre que ce soit si lui même ou des utilisateurs du serveur auquel il aura donné accès ne possédaient pas les droits requis pour y avoir accès. 
</p>

<h3>Copyrights</h3>
<p>
<img border="0" alt="Copyrighted.com Registered &amp; Protected 
KKD9-RZJQ-U85P-V5VU" title="Copyrighted.com Registered &amp; Protected 
KKD9-RZJQ-U85P-V5VU" width="150" height="40" src="http://static.copyrighted.com/images/seal.gif"><br>
MTFO.fr est déclaré sous le numero KKD9-RZJQ-U85P-V5VU du site <a href="http://www.copyrighted.com/">http://www.copyrighted.com</a>.<br> Fingerprint : 0fe49ffdfc3e0255d25f2ef49b5f3bcd24dc0100b30ad00da448a909b8d83418<br>
Certaines images appartiennent aux sociétés suivantes : Mojang AB(<a href="http://mojang.com">http://mojang.com</a>), Glyphicons(<a href="http://glyphicons.com/">http://glyphicons.com/</a>).
</p>
 </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">J'ai pris connaissance des conditions</button>
  </div>
</div>

</div> <!-- /.container -->

	<!-- Le javascript -->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script src="assets/js/bootstrap-transition.js"></script>
	<script src="assets/js/bootstrap-collapse.js"></script>
	<script src="assets/js/bootstrap-modal.js"></script>
	<script src="assets/js/bootstrap-dropdown.js"></script>
	<script src="assets/js/bootstrap-button.js"></script>
	<script src="assets/js/bootstrap-tab.js"></script>
	<script src="assets/js/bootstrap-alert.js"></script>
	<script src="assets/js/bootstrap-tooltip.js"></script>
	<script src="assets/js/jquery.ba-hashchange.min.js"></script>
	<script src="assets/js/jquery.validate.min.js"></script>
	<script src="assets/js/jquery.placeholder.min.js"></script>
	<script src="assets/js/jquery.jigowatt.js"></script>
    <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.4/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/jquery.jigowatt.js"></script><!-- AJAX Form Submit -->

  </body>
 
	<footer>
		<hr>
		<center style="margin-bottom: -25px;">
	        <span class="copyright">Copyright © 2013 - MTFO Version 4.1.4 - Tous droits réservés. <a style="color: rgb(15, 134, 180);" href="#ml" role="button" data-toggle="modal">Mentions légales</a></span>
        </center>
	<br />
	<br />
<center><script type="text/javascript"><!--
google_ad_client = "ca-pub-4102336494627461";
/* PUB-FOOTER */
google_ad_slot = "5066835698";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<br>
<div style="color:#000"><a href="partners.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0" style="color:#000">Partenaires</a> | <a href="info.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0" style="color:#000">Contact</a> | <a href="info.php?PHPSESSID=188jjms9ha69dutqd6goli5jt0" style="color:#000">Suggestion</a> | <a href="?PHPSESSID=188jjms9ha69dutqd6goli5jt0" style="color: #8D0000;">Recrutement</a></div>
<br>
</center>
	</footer>
</html>
